<h1>Fill  registration info</h1>
<form name="form_reg" action="" method='post' class="form-control">

		<div class="form-group">
				<div><label>Username: </label></div>
				<div><input type='text' name='username'></div>
		</div>

		<div class="form-group">
				<div><label>Email: </label></div>
				<div><input type='email' name='email'></div>
		</div>

		<div class="form-group">
				<div><label>Login: </label></div>
				<div><input type='text' name='login'></div>
		</div>

		<div class="form-group">
				<div><label>Password: </label></div>
				<div><input type='password' name='password'></div>
		</div>

		<div class="form-group">
				<input type='hidden' name="q" value='reg'>
				<input type='submit' value='Register'>
		</div>
</form>

