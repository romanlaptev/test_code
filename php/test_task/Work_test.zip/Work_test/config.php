<?php
return array(
	//'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR,
	'db'=>array(
		//'connectionString' => 'mysql:host=localhost;dbname=db1',
		'connectionString' => 'mysql:host=localhost',
		'dbName' => 'db2',
		'dbUser' => 'root',
		'password' => 'master',
		//'charset' => 'utf8',
	)
);
?>
