<?php
/*
https://docs.joomla.org/Plugin/Events/Content#onContentPrepareData
https://docs.joomla.org/Inserting,_Updating_and_Removing_data_using_JDatabase/ru
https://github.com/joomla/joomla-cms/blob/staging/plugins/user/profile/profile.php#L68

https://docs.joomla.org/Adding_custom_fields_to_core_components_using_a_plugin/ru
*/

// no direct access
defined( '_JEXEC' ) or die;

class plgContentChangeForms extends JPlugin
{
	//protected $autoloadLanguage = true;
	
	public function onContentBeforeDisplay ( $context, &$row, &$params, $page = 0) {
JError::raiseNotice( 100, 'onContentBeforeDisplay event plugin fired..');
		return true;
		
//		$param = $this->params->get("field2", "defaultValue");
//		return "<h3>".$param."</h3>";
	}//end

	public function onContentPrepare($context, &$row, &$params, $page = 0)	{
JError::raiseNotice( 100, 'onContentPrepare event plugin fired..');
		return true;
	}//end
		
		
	public function onContentPrepareData( $context, $data) {
JError::raiseNotice( 100, 'onContentPrepareData event plugin fired..');
		// Check we are manipulating a valid form.
		//if (!in_array($context, array('com_users.profile', 'com_users.user', 'com_users.registration', 'com_admin.profile')))
		//{
			return true;
		//}		
		
	}//end


	public function onContentPrepareForm($form, $data)
	{
//JError::raiseNotice( 100, 'onContentPrepareForm event plugin fired..' );

		// Check we are manipulating a valid form.
		$name = $form->getName();
//JError::raiseNotice( 100, 'form name:'.$name );
		if (!in_array($name, 
				array(
					'com_product.product', 
					'com_product.product_category'
					)
				)
			)
		{
			return true;
		}
				
		//$app    = JFactory::getApplication();
		//$option = $app->input->get('option');

		//$changeForm = false;
		//if( $option == "com_product" ){
		//	$changeForm = true;
		//}
		//if( $option == "com_product_category"  ){
		//	$changeForm = true;
		//}

		//if( !$changeForm ){
		//	return true;
		//}

//JFactory::getApplication()->enqueueMessage('MY MESSAGE');
//echo "<pre>";
//print_r( $option );
//echo "</pre>";

	//if ($app->isClient('site'))
	//{
		//JForm::addFormPath(__DIR__ . '/forms');
		//$form->loadFile('fields', false);
	//}


//--------------------- get data custom fields (page_header_H1....)
		$data->jcfields = array();
		$itemID = "com_product_".$data->id;
		
		$db = JFactory::getDbo();
		$query = "SELECT #__fields.name as name, value FROM #__fields_values 
LEFT JOIN #__fields ON #__fields.id = #__fields_values.field_id
WHERE #__fields_values.item_id = '".$itemID."'";
//echo $query;

		$db->setQuery($query);
		$data->jcfields = $db->loadObjectList();
		
		//create data property for custom fields
		$data->page_header_h1 = $data->jcfields[0]->value;
		
echo "data:<pre>";
print_r( $data );
echo "</pre>";

//--------------------- add new custom field on the form
$element = new SimpleXMLElement('<fieldset name="advanced">
<field name="page_header_h1"
type="text"
label="page header H1"
description="field for page header H1"
class="inputbox"
size="30"
required="false" />
</fieldset>');
$form->setField($element);
/*
SimpleXMLElement Object
(
    [@attributes] => Array
        (
            [name] => name
            [filter] => safehtml
            [type] => text
            [label] => COM_PRODUCT_FORM_LBL_PRODUCT_NAME
            [description] => COM_PRODUCT_FORM_DESC_PRODUCT_NAME
            [hint] => COM_PRODUCT_FORM_LBL_PRODUCT_NAME
        )
)
*/

//echo "<pre>";
//print_r( $form->getXml() );
//print_r( $form->getFieldXml( "name") );
//echo "</pre>";
            //foreach($form->getFieldset() as $field) {
                //echo $field->renderField();        
            //}


		return true;
	}//end


    function onContentBeforeSave($context, $article, $isNew) {
        //JError::raiseNotice( 100, 'onContentBeforeSave plugin fired!' );
        
        //com_product.product
		JFactory::getApplication()->enqueueMessage('context: '.$context);
		JFactory::getApplication()->enqueueMessage('ID: '.$article->id);

//--------------------- update custom fields (page_header_H1....)

/*
		//https://docs.joomla.org/Inserting,_Updating_and_Removing_data_using_JDatabase/ru		
		// Create and populate an object.
		$obj = new stdClass();
		$obj->field_id = 2;
		$obj->item_id="com_product_"."2";
		$obj->value="test2";

		// Insert the object into the user profile table.
		$result = JFactory::getDbo()->insertObject('#__fields_values', $obj);
*/
//--------------------------
		
        return true;
    }//end


    function onContentAfterSave($context, $article, $isNew) {
        //JError::raiseNotice( 100, 'onContentAfterSave plugin fired!' );
        return true;
    }//end


}//end class
