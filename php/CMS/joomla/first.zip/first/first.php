<?php
// no direct access
defined( '_JEXEC' ) or die;

class plgContentFirst extends JPlugin
{
	//protected $autoloadLanguage = true;
	public function onContentBeforeDisplay ( $context, &$row, &$params, $page = 0)
	{
		$param = $this->params->get("field1", "defaultValue");
		return "<h1>".$param."</h2>";
	}
}
