<?php
//запрещает доступ не из joomla
defined('_JEXEC') or die;
//создаём класс плагина 
class plgContentGreet extends JPlugin
{  
    //задаём тип события
    public function onContentBeforeDisplay( $context, &$row, &$params, $page = 0 )
    {
        //получаем значение поля приветствия
            $param = $this->params->get('greet', 'defaultValue');
        //выводим приветствие
            return "<h2>".$param."</h2>";       
    }
}