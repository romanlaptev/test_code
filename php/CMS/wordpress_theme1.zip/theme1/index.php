<?php
/**
 * The main template file
 */
get_header();
 //get_header("custom");// no wp_head();
 
	//wp_nav_menu( array( 'theme_location' => 'primary' ) );
	
//https://wp-kama.ru/function/wp_page_menu	
	wp_page_menu();
//wp_list_pages();	
?>

<h1>index page</h1>
<h3>wp-content/themes/theme1/index.php</h3>

<ul>
	<li>https://wp-kama.ru/id_71/fayl-shablona-functionsphp-v-wordpress.html</li>
	<li>https://wp-kama.ru/hook/after_setup_theme</li>
	<li>https://developer.wordpress.org/themes/basics/theme-functions/</li>
</ul>
	
<ul>Menu:
	<li>https://wp-kama.ru/id_140/polzovatelskoe-menyu-v-wp-30-wp_nav_menu.html</li>
	<li>https://wp-kama.ru/function/register_nav_menus</li>
	<li>https://wp-kama.ru/function/wp_nav_menu</li>
	<li>https://misha.blog/wordpress/wp_nav_menu.html</li>
	<li>https://wp-kama.ru/function/wp_page_menu</li>
	<li>https://codex.wordpress.org/Navigation_Menus</li>
</ul>

<?php
/*
		if ( have_posts() ) {
			// Load posts loop.
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content/content' );
			}

			// Previous/next page navigation.
			twentynineteen_the_posts_navigation();

		} else {

			// If no content, include the "No posts found" template.
			get_template_part( 'template-parts/content/content', 'none' );

		}
*/		
?>

<?php
get_footer();
