<?php
//add_filter( 'init', 'wp_init' );
add_action( 'after_setup_theme', 'theme1_after_setup' );
//add_filter( 'wp_footer', 'theme1_footer' );

function wp_init(){
	echo "WP, plugins, theme loaded...";
	echo "INIT functions, wp-content/themes/theme1/functions.php";
	echo "<br>";
}//end

function theme1_after_setup(){
	echo "function  theme1_after_setup()";
	echo "<br>";
	
   	register_nav_menus( [
   		'top_menu' => 'header menu',
   		'bottom_menu' => 'footer menu'
   	] );	
 	
 	//register_nav_menu( 'primary', __( 'Primary Menu' ) );
// 	register_nav_menu( 'primary', __( 'Primary Menu', 'twentyeleven' ) );

// 		register_nav_menus(
// 			array(
// 				'menu-1' => __( 'Primary', 'twentynineteen' ),
// 				'footer' => __( 'Footer Menu', 'twentynineteen' ),
// 				'social' => __( 'Social Links Menu', 'twentynineteen' ),
// 			)
// 		);

}//end


function theme1_footer(){
	echo "function  theme1_footer()";
	echo "<br>";
}//end
