<?php
/**
  * @package WordPress
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>test theme1</title>
	<?php wp_head(); ?>
</head>

<body>
<?php
	//wp_nav_menu("menu=menu1");
	
 	wp_nav_menu( array( 
// 		'theme_location' => 'top_menu',
 		'menu' => 'menu1'
 	));

 	wp_nav_menu( array( 
 		'theme_location' => 'bottom_menu'
 	));

// 			wp_nav_menu(
// 				array(
// 					'theme_location' => 'menu-1',
// 					'menu_class'     => 'main-menu',
// 					'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
// 				)
// 			);
	
?>

