<?php 
// 					wp_nav_menu(
// 						array(
// 							'theme_location' => 'footer',
// 							'menu_class'     => 'footer-menu',
// 							'depth'          => 1,
// 						)
// 					);
	//wp_nav_menu("menu=menu2");
	
//https://misha.blog/wordpress/wp_nav_menu.html	
//https://wp-kama.ru/function/wp_nav_menu
	wp_nav_menu( array( 
		'theme_location' => 'bottom_menu',
		'items_wrap'     => '<ul>Menu 2: %3$s</ul>',
		'menu' => 'menu2',
		'menu_id'     => '#bottom-menu',
		'menu_class'     => 'menu-bottom',
		'container'     => 'div',
		//'container_class'     => 'menu-{menu slug}-container',
		'container_id'     => '#block-bottom-menu',
		'before'     => '***',
		'after'     => '***',
		'link_before'     => '---',
		'link_after'     => '---'
	));
	
// 			wp_nav_menu(
// 				array(
// 					'theme_location' => 'menu-1',
// 					'menu_class'     => 'main-menu',
// 					'items_wrap'     => '<ul id="%1$s" class="%2$s">%3$s</ul>',
// 				)
// 			);
	
wp_footer(); 
?>

</body>
</html>
