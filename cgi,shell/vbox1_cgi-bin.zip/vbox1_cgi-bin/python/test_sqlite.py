#!/usr/bin/python
# -*- coding: utf-8 -*-
print "Content-type:text/html"
print ""
print "<html>"
print "<head>"
print "<meta charset='utf-8'/>"
print "</head>"
print "<body>"
print "<h2>Test Python: SQLite</h2>"
import sqlite3

print "sqlite3.apilevel: " + sqlite3.apilevel
print "<br/>\n"

print sqlite3.threadsafety
print "<br/>\n"

print sqlite3.paramstyle
print "<br/>\n"

import sqlite as db
c = db.connect(database="db1.sqlite")
cu = c.cursor()


c.close()
print "</body>"
print "</html>"
