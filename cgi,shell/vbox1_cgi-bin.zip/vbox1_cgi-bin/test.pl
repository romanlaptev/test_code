#!/usr/bin/perl
print "Content-Type: text/html\n\n";
#require $ENV{'DOCUMENT_ROOT'}."/cgi-bin/lvt.pm";

print "<h1>Hello Perl world</h1>";
